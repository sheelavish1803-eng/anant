---
name: Aura Precision
colors:
  surface: '#f9f9f9'
  surface-dim: '#dadada'
  surface-bright: '#f9f9f9'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3f4'
  surface-container: '#eeeeee'
  surface-container-high: '#e8e8e8'
  surface-container-highest: '#e2e2e2'
  on-surface: '#1a1c1c'
  on-surface-variant: '#4c4546'
  inverse-surface: '#2f3131'
  inverse-on-surface: '#f0f1f1'
  outline: '#7e7576'
  outline-variant: '#cfc4c5'
  surface-tint: '#5e5e5e'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#1b1b1b'
  on-primary-container: '#848484'
  inverse-primary: '#c6c6c6'
  secondary: '#005cba'
  on-secondary: '#ffffff'
  secondary-container: '#5095fe'
  on-secondary-container: '#002d61'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#1a1c1d'
  on-tertiary-container: '#838486'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e2e2e2'
  primary-fixed-dim: '#c6c6c6'
  on-primary-fixed: '#1b1b1b'
  on-primary-fixed-variant: '#474747'
  secondary-fixed: '#d7e3ff'
  secondary-fixed-dim: '#aac7ff'
  on-secondary-fixed: '#001b3e'
  on-secondary-fixed-variant: '#00458e'
  tertiary-fixed: '#e2e2e4'
  tertiary-fixed-dim: '#c6c6c8'
  on-tertiary-fixed: '#1a1c1d'
  on-tertiary-fixed-variant: '#454749'
  background: '#f9f9f9'
  on-background: '#1a1c1c'
  surface-variant: '#e2e2e2'
  text-secondary: '#6E6E73'
  divider-subtle: '#D2D2D7'
  status-accent: '#FF3008'
typography:
  display-hero:
    fontFamily: Inter
    fontSize: 80px
    fontWeight: '700'
    lineHeight: '1.05'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 56px
    fontWeight: '600'
    lineHeight: '1.1'
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 40px
    fontWeight: '600'
    lineHeight: '1.1'
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: 0em
  body-lg:
    fontFamily: Inter
    fontSize: 21px
    fontWeight: '400'
    lineHeight: '1.45'
    letterSpacing: 0.01em
  body-md:
    fontFamily: Inter
    fontSize: 17px
    fontWeight: '400'
    lineHeight: '1.47'
    letterSpacing: -0.022em
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: '1.2'
    letterSpacing: 0.02em
  caption:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: '1.3'
    letterSpacing: 0em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  section-gap-desktop: 160px
  section-gap-mobile: 80px
  content-stack: 24px
  gutter: 24px
  margin-desktop: 10vw
  margin-mobile: 20px
---

## Brand & Style

This design system embodies an uncompromising commitment to minimalist luxury and high-fidelity precision. It is designed to evoke a sense of professional authority and aspirational clarity, positioning the product as a pinnacle of industrial design and engineering.

The visual style is **Corporate / Modern** with a focus on editorial storytelling. It leverages high-contrast color shifts and monumental typography to create a rhythmic, immersive experience. The aesthetic is "surgical"—clean, intentional, and devoid of unnecessary decoration, ensuring that high-resolution product photography remains the primary focal point.

## Colors

The palette is strictly monochromatic, punctuated only by a functional interactive blue and rare status accents. The system relies on a binary relationship between `pure-white` and `deep-black` to define distinct narrative chapters.

- **Primary & Neutral:** Used interchangeably to create high-contrast "Dark Mode" and "Light Mode" sections that signal shifts in content focus.
- **Secondary:** Reserved exclusively for calls-to-action and navigational links to ensure clear interactive affordance.
- **Surface Secondary:** A soft, neutral gray used for secondary containment, such as product comparison grids or footer backgrounds, providing a subtle break from the starkness of the primary surfaces.

## Typography

The typographic system utilizes **Inter** as a robust, geometric fallback to San Francisco. Hierarchy is established through extreme scale and weight contrast rather than color variation.

Large headlines must utilize **tight tracking** (negative letter spacing) to maintain a cohesive, high-end editorial feel. Body text is optimized for legibility with a generous line height. Large scale metrics (e.g., "2x", "50%") should be treated as display elements, using the `display-hero` or `headline-lg` styles to anchor feature sections visually.

## Layout & Spacing

The layout philosophy follows a **Single-column scroll** model with immersive, full-width sections. It prioritizes "one thought at a time," using generous vertical whitespace to isolate concepts.

- **Grid:** A 12-column grid is used internally within sections for product comparisons or multi-card layouts, but the primary narrative remains centered.
- **Breakpoints:** Transitions occur at 768px (Tablet) and 1068px (Desktop). On mobile, vertical padding is reduced by 50%, and display typography scales down to maintain readability.
- **Margins:** Fluid side margins (10vw) ensure content remains centered and focused on large displays, creating a "contained" feel for body copy while allowing imagery to bleed to the edges when necessary.

## Elevation & Depth

This design system avoids traditional drop shadows in favor of **Flat Layering** and **Tonal Depth**.

- **Surface Tiers:** Hierarchy is created by stacking elements on high-contrast backgrounds.
- **Glassmorphism:** Navigation bars and sticky sub-menus utilize a high-density backdrop blur (20px+) with 80% opacity to maintain context while scrolling.
- **Product Depth:** Product imagery should feature "grounding shadows"—subtle, soft-contact shadows that sit directly beneath the hardware to provide a sense of three-dimensional space without appearing "floated."

## Shapes

The shape language combines the precision of straight lines with the approachability of large radii.

- **Cards:** Feature cards in grids utilize a `1.5rem` (24px) radius to feel modern and friendly.
- **CTA Buttons:** Utilize a full pill/capsule shape for primary actions to distinguish them from structural elements.
- **Dividers:** When required, use 1px hair-lines in `divider-subtle` (#D2D2D7) to maintain a technical, engineered appearance.

## Components

### Buttons & Links
- **Primary CTA:** A pill-shaped button using `surface-inverse` background with `text-inverse`. Transitions to 90% opacity on hover.
- **Text Links:** `link-primary` blue with an arrow glyph (`→`). Hover state triggers a subtle underline.

### Cards
- **Feature Cards:** High-radius containers with `surface-secondary` backgrounds. Content within cards should be center-aligned or bottom-aligned with generous internal padding (40px+).

### Input Fields
- **Search/Forms:** Minimalist outlines or soft-gray fills with `12px` roundedness. Focus states should use a subtle 2px blue ring.

### Lists & Comparison
- **Comparison Tables:** Strictly horizontal rules. No vertical borders. Bold headings for product names, regular weight for specs.

### Navigation
- **Local Nav:** A thin, sticky bar with a backdrop blur. Links are small, `label-md` uppercase or medium weight, using `text-secondary` and shifting to `text-primary` when active.